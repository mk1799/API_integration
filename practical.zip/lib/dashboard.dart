import 'package:flutter/material.dart';
import 'dart:async';
import 'package:http/http.dart' as http;
Future<Post> fetchpost() async {
  final response =
      await http.get('https://www.iroidsolutions.com/interview/test.json');
      return Post.fromJson(json.decode(response.body));
}

class Post {
  final String name, emil, phone, id, company, gender;

  Post({
    this.name,
    this.emil,
    this.phone,
    this.id,
    this.company,
    this.gender,
  });

  factory Post.fromJson(Map<String, dynamic> json) {
    return new Post(
        name: json['name'].toString(),
        emil: json['email'].toString(),
        phone: json['phone'].toString(),
        id: json['_id'].toString(),
        company: json['company'].toString(),
        gender: json['gender'].toString());
  }
}
void main()=>myDashboard();

class myDashboard extends StatefulWidget {
  myDashboard({Key key, this.email}) : super(key: key);
  final String email;
  @override
  _myDashboardState createState() => _myDashboardState();
}
class _myDashboardState extends State<myDashboard> {
  Future<Post> futurepost;
  @override
  void initState() {
    super.initState();
    futurepost = fetchpost();
  }
   @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Fetch Data Example',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Fetch Data Example'),
        ),
        body: Center(
        child: FutureBuilder<Post>(
            future: futurepost,
            builder: (context, snapshot) {
              if (snapshot.hasData) {
                return Text(snapshot.data.name);
              } else if (snapshot.hasError) {
                return Text("${snapshot.error}");
              }

              // By default, show a loading spinner.
              return CircularProgressIndicator();
            },
          ),
        ),
      ),
    );
  }
}
